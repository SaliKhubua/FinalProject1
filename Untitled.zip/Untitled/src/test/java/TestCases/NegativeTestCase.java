package TestCases;
import StepObject.NegativeTestStep;
import io.restassured.response.Response;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class NegativeTestCase {

    NegativeTestStep negativeTestStep = new NegativeTestStep();

    @Test
    public void testCreateOrderWithInvalidId() {
        Response response = negativeTestStep.createOrderWithInvalidId();
        assertThat(response.getStatusCode()).as("Check status code").isEqualTo(500);
        String responseBody = response.getBody().asString();
        assertThat(responseBody).contains("something bad happened");
    }

    @Test
    public void testCreateOrderWithInvalidPetId() {
        Response response = negativeTestStep.createOrderWithInvalidPetId();
        assertThat(response.getStatusCode()).as("Check status code").isEqualTo(500);
        String responseBody = response.getBody().asString();
        assertThat(responseBody).contains("something bad happened");
    }
}