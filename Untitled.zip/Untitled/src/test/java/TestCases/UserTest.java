package TestCases;

import DataObject.User;
import StepObject.UserStep;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import static org.assertj.core.api.Assertions.assertThat;

public class UserTest {
    private final UserStep userStep = new UserStep();


    //1.
    @Test
    public void testCreateUser() {
        User user = new User(11, "SaliTest", "salt", "Test", "sali@gmail.com", "Sali@Test123", "555112233", 1);
        Response response = userStep.createUser(user);

        System.out.println("Response Body: " + response.getBody().asString());
        assertThat(response.getStatusCode()).as("Check status code").isEqualTo(200);
        assertThat(response.jsonPath().getString("message")).as("Check user ID").isEqualTo(String.valueOf(user.getId()));

    }


    //2.
    @Test(dependsOnMethods = "testCreateUser")
    public void testGetUserByUsername() {
        String username = "SaliTest";
        Response response = userStep.getUserByUsername(username);

        System.out.println("Response Body: " + response.getBody().asString());
        assertThat(response.getStatusCode()).as("Check status code").isEqualTo(200);
        assertThat(response.jsonPath().getString("username")).as("Check username").isEqualTo(username);
        assertThat(response.jsonPath().getString("firstName")).as("Check firstName").isEqualTo("salt");
        assertThat(response.jsonPath().getString("lastName")).as("Check lastName").isEqualTo("Test");
        assertThat(response.jsonPath().getString("email")).as("Check email").isEqualTo("sali@gmail.com");
        assertThat(response.jsonPath().getString("password")).as("Check password").isEqualTo("Sali@Test123");
        assertThat(response.jsonPath().getString("phone")).as("Check phone").isEqualTo("555112233");
        assertThat(response.jsonPath().getInt("userStatus")).as("Check userStatus").isEqualTo(1);
    }


    //3.
    @Test(dependsOnMethods = "testCreateUser")
    public void testUpdateUser() {
        String username = "SaliTest";
        String updatedPhone = "555112239";
        Response response = userStep.updateUser(username, updatedPhone);
        System.out.println("Response Body: " + response.getBody().asString());
        assertThat(response.getStatusCode()).as("Check status code").isEqualTo(200);
    }

    //4.
    @Test(dependsOnMethods = "testUpdateUser")
    public void testGetUserByUsername1() {

        String username = "SaliTest";
        String updatedPhone = "555112239";
        Response response = userStep.getUserByUsername(username);
        System.out.println("Response Body: " + response.getBody().asString());
        assertThat(response.getStatusCode()).as("Check status code").isEqualTo(200);
        assertThat(response.jsonPath().getString("username")).as("Check username").isEqualTo(username);
        assertThat(response.jsonPath().getString("phone")).as("Check phone number").isEqualTo(updatedPhone);
    }

    //5.
    @Test(dependsOnMethods = "testGetUserByUsername")
    public void testLoginUser() {
        String username = "SaliTest";
        String password = "Sali@Test123";

        Response response = userStep.loginUser(username, password);

        System.out.println("Response Body: " + response.getBody().asString());

        assertThat(response.getStatusCode()).as("Check status code").isEqualTo(200);

        String message = response.jsonPath().getString("message");
        assertThat(message).as("Check message").isNotEmpty().isNotNull();
    }


    //6.
    @Test(dependsOnMethods = "testLoginUser")
    public void testLogoutUser() {

        Response response = userStep.logoutUser();
        System.out.println("Response Body: " + response.getBody().asString());
        assertThat(response.getStatusCode()).as("Check status code").isEqualTo(200);
        String message = response.jsonPath().getString("message");
        assertThat(message).as("Check message").isEqualTo("ok");
    }


    //7.
    @Test(dependsOnMethods = "testLogoutUser")
    public void testDeleteUser() {
        String usernameToDelete = "SaliTest";
        Response response = userStep.deleteUser(usernameToDelete);
        assertThat(response.getStatusCode()).as("Check status code").isEqualTo(200);

    }
}