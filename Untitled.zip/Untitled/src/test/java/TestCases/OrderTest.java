package TestCases;

import StepObject.OrderStep;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import static org.assertj.core.api.Assertions.assertThat;

public class OrderTest {
    private final OrderStep orderStep = new OrderStep();
    private int orderId;

    //1.
    @Test
    public void testPlaceOrder() {
        int id = 123456;
        int petId = 78910;
        int quantity = 2;
        String status = "placed";

        Response response = orderStep.placeOrder(id, petId, quantity, status);

        orderId = response.jsonPath().getInt("id");


        assertThat(response.getStatusCode()).as("Check status code").isEqualTo(200);
        assertThat(response.jsonPath().getInt("id")).as("Check ID").isEqualTo(id);
        assertThat(response.jsonPath().getInt("petId")).as("Check Pet ID").isEqualTo(petId);
        assertThat(response.jsonPath().getInt("quantity")).as("Check Quantity").isEqualTo(quantity);
        assertThat(response.jsonPath().getString("status")).as("Check Status").isEqualTo(status);
    }


    //2.
    @Test(dependsOnMethods = "testPlaceOrder")
    public void testRetrieveOrder() {
        int petId = 78910;
        int quantity = 2;
        String status = "placed";


        Response getResponse = orderStep.getOrderById(orderId);

        assertThat(getResponse.getStatusCode()).as("Check status code").isEqualTo(200);
        assertThat(getResponse.jsonPath().getInt("id")).as("Check ID").isEqualTo(orderId);
        assertThat(getResponse.jsonPath().getInt("petId")).as("Check Pet ID").isEqualTo(petId);
        assertThat(getResponse.jsonPath().getInt("quantity")).as("Check Quantity").isEqualTo(quantity);
        assertThat(getResponse.jsonPath().getString("status")).as("Check Status").isEqualTo(status);
    }


    //3.
    @Test(dependsOnMethods = "testRetrieveOrder")
    public void testDeleteOrder() {
        Response deleteResponse = orderStep.deleteOrderById(orderId);
        assertThat(deleteResponse.getStatusCode()).as("Check status code").isEqualTo(200);
        Response getResponse = orderStep.getOrderById(orderId);
        assertThat(getResponse.getStatusCode()).as("Check that order is deleted").isEqualTo(404);
    }


    //4.
    @Test(dependsOnMethods = "testDeleteOrder")
    public void testDeleteSameOrderAgain() {
        Response deleteResponse = orderStep.deleteOrderById(orderId);
        assertThat(deleteResponse.getStatusCode()).as("Check status code").isEqualTo(404);
        assertThat(deleteResponse.getBody().asString()).as("Check response body").contains("Order Not Found");
    }


    //5.
    @Test(dependsOnMethods = "testDeleteOrder")
    public void testGetOrderByIdAfterDelete() {
        Response getResponse = orderStep.getOrderById(orderId);
        assertThat(getResponse.getStatusCode()).as("Check status code").isEqualTo(404);
        assertThat(getResponse.getBody().asString()).as("Check response body").contains("Order not found");
    }

}


