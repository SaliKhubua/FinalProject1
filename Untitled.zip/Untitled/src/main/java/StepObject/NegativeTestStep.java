package StepObject;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class NegativeTestStep {

    private static final String BASE_URL = "https://petstore.swagger.io/v2";

    public Response createOrderWithInvalidId() {
        String invalidIdOrderJson = "{\n" +
                "  \"id\": \"invalid_id\",  // Invalid id (should be an integer)\n" +
                "  \"petId\": 0,\n" +
                "  \"quantity\": 0,\n" +
                "  \"shipDate\": \"2025-02-05T18:00:00.553Z\",\n" +
                "  \"status\": \"placed\",\n" +
                "  \"complete\": true\n" +
                "}";

        RestAssured.baseURI = BASE_URL;
        return RestAssured.given()
                .contentType(ContentType.JSON)
                .body(invalidIdOrderJson)
                .when()
                .post("/store/order")
                .then()
                .extract().response();
    }

    public Response createOrderWithInvalidPetId() {
        String invalidPetIdOrderJson = "{\n" +
                "  \"id\": 1,\n" +
                "  \"petId\": \"invalid_pet_id\",  // Invalid petId (should be a numeric id)\n" +
                "  \"quantity\": 0,\n" +  // Correct quantity
                "  \"shipDate\": \"2025-02-05T18:00:00.553Z\",\n" +
                "  \"status\": \"placed\",\n" +
                "  \"complete\": true\n" +
                "}";

        RestAssured.baseURI = BASE_URL;
        return RestAssured.given()
                .contentType(ContentType.JSON)
                .body(invalidPetIdOrderJson)
                .when()
                .post("/store/order")
                .then()
                .extract().response();
    }


    public Response createOrderWithInvalidQuantity(int invalidQuantity) {
        String validOrderJson = "{\n" +
                "  \"id\": 1,\n" +
                "  \"petId\": 0,\n" +
                "  \"quantity\": " + invalidQuantity + ",\n" +
                "  \"shipDate\": \"2025-02-05T18:00:00.553Z\",\n" +
                "  \"status\": \"placed\",\n" +
                "  \"complete\": true\n" +
                "}";

        RestAssured.baseURI = "https://petstore.swagger.io/v2";
        return RestAssured.given()
                .contentType(ContentType.JSON)
                .body(validOrderJson)
                .when()
                .post("/store/order")
                .then()
                .extract().response();
    }

}

