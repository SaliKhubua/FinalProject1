package StepObject;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.given;

public class OrderStep {
    private static final String BASE_URL = "https://petstore.swagger.io/v2";

    public Response placeOrder(int id, int petId, int quantity, String status) {
        RestAssured.baseURI = BASE_URL;

        String orderJson = "{\n" +
                "  \"id\": " + id + ",\n" +
                "  \"petId\": " + petId + ",\n" +
                "  \"quantity\": " + quantity + ",\n" +
                "  \"status\": \"" + status + "\"\n" +
                "}";

        return given()
                .contentType(ContentType.JSON)
                .body(orderJson)
                .when()
                .post("/store/order")
                .then()
                .extract().response();



    }

    public Response getOrderById(int orderId) {
        RestAssured.baseURI = BASE_URL;

        return given()
                .pathParam("orderId", orderId)
                .when()
                .get("/store/order/{orderId}")
                .then()
                .extract().response();
    }

    public Response deleteOrderById(int orderId) {

        RestAssured.baseURI = BASE_URL;


        return given()
                .pathParam("orderId", orderId)
                .when()
                .delete("/store/order/{orderId}")
                .then()
                .extract().response();
    }

}
