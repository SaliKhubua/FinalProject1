package StepObject;

import DataObject.User;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.given;

public class UserStep {
    private static final String BASE_URL = "https://petstore.swagger.io/v2";

    public Response logoutUser() {
        RestAssured.baseURI = BASE_URL;

        return given()
                .when()
                .get("/user/logout")
                .then()
                .extract().response();

    }

    public Response deleteUser(String username) {
        RestAssured.baseURI = BASE_URL;
        return given()
                .pathParam("username", username) // path parameter for the username
                .when()
                .delete("/user/{username}") // DELETE request to delete the user by username
                .then()
                .extract().response();

    }


    public Response loginUser(String username, String password) {
        RestAssured.baseURI = BASE_URL;

        return given()
                .queryParam("username", username)
                .queryParam("password", password)
                .when()
                .get("/user/login")
                .then()
                .extract().response();
    }

    public Response createUser(User user) {
        RestAssured.baseURI = BASE_URL;
        String userJson = "{\n" +
                "  \"id\": " + user.getId() + ",\n" +
                "  \"username\": \"" + user.getUsername() + "\",\n" +
                "  \"firstName\": \"" + user.getFirstName() + "\",\n" +
                "  \"lastName\": \"" + user.getLastName() + "\",\n" +
                "  \"email\": \"" + user.getEmail() + "\",\n" +
                "  \"password\": \"" + user.getPassword() + "\",\n" +
                "  \"phone\": \"" + user.getPhone() + "\",\n" +
                "  \"userStatus\": " + user.getUserStatus() + "\n" +
                "}";

        return given()
                .contentType(ContentType.JSON)
                .body(userJson)
                .when()
                .post("/user")
                .then()
                .extract().response();
    }

    public Response getUserByUsername(String username) {
        RestAssured.baseURI = BASE_URL;

        return given()
                .pathParam("username", username)
                .when()
                .get("/user/{username}")
                .then()
                .extract().response();
    }

    public Response updateUser(String username, String updatedPhone) {
        RestAssured.baseURI = BASE_URL;

        String updatedUserJson = "{\n" +
                "  \"id\": 11,\n" +
                "  \"username\": \"" + username + "\",\n" +
                "  \"firstName\": \"salt\",\n" +
                "  \"lastName\": \"Test\",\n" +
                "  \"email\": \"sali@gmail.com\",\n" +
                "  \"password\": \"Sali@Test123\",\n" +
                "  \"phone\": \"" + updatedPhone + "\",\n" +
                "  \"userStatus\": 1\n" +
                "}";

        return given()
                .contentType(ContentType.JSON)
                .body(updatedUserJson)
                .when()
                .put("/user/{username}", username)
                .then()
                .extract().response();
    }


}
